#include "Giasuc.h"
#include <iostream>
using namespace std;

Giasuc::Giasuc()
{
    loai = 0;
}

Giasuc::~Giasuc()
{
}

int Giasuc::sinhcon()
{
    return 0;
}

int Giasuc::sua()
{
    return 0;
}

void Giasuc::tiengkeu()
{
}

int Giasuc::getloai()
{
    return 0;
}
