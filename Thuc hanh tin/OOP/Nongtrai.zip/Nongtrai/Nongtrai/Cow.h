#pragma once
#include "giasuc.h"
#include <iostream>
using namespace std;
class Cow : public Giasuc
{
public:
	Cow();
	~Cow();
	virtual int sinhcon();
	virtual int sua();
	virtual void tiengkeu();
	virtual int getloai();
};

